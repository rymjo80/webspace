var step = 0;
var animation;
var size;
var turbo;
var viewer;
var speed;
var myInterval;
var playing;

function startAnimation() {
    document.getElementById("stop").disabled = false;
    document.getElementById("start").disabled = true;
    document.getElementById("animation").disabled = true;
    animation = getAnimationTest();
    size = getSize();  
    turbo = getSpeed();
    viewer = getViewer();
    viewer.style.fontSize = size;
    speed = getSpeed();
    playing = true;
    myInterval = setInterval(animate, speed, animation, viewer);
}

function animate(animation, viewer) {
    viewer.innerHTML = animation[step];
    if (step < animation.length - 1) {
        step += 1;
    } else {
        step = 0;
    }
}

function changeAnimation() {
    viewer = getViewer();
    viewer.style.fontSize = getSize();
    speed = getSpeed();
    animation = getAnimationTest();
    if (playing) {
        clearInterval(myInterval);
        myInterval = setInterval(animate, speed, animation, viewer);
    }
}

function stopAnimation() {
    document.getElementById("start").disabled = false;
    document.getElementById("stop").disabled = true;
    document.getElementById("animation").disabled = false;
    clearInterval(myInterval);
    playing = false;
    step = 0;
}

function getAnimationTest() {
    var selected = document.getElementById("animation").value
    var animation = ANIMATIONS[selected];
    return animation.split("=====\n");
}

function getSize() {
    return document.getElementById("size").value;
}

function getSpeed() {
    speed = 250;
    if (document.getElementById("turbo").checked) {
        speed = 50;
    }
    return speed;
}

function getViewer() {
    return document.getElementById("animation-viewer");
}

